let sunX = 0;
let clouds = [];

function setup() {
  createCanvas(800, 400);

  // Criando nuvens com posições aleatórias
  for (let i = 0; i < 5; i++) {
    clouds.push({
      x: random(width),
      y: random(50, 150),
      speed: random(0.3, 1)
    });
  }
}

function draw() {
  // Céu - muda de cor ao longo do dia
  let skyColor = lerpColor(color(135, 206, 235), color(25, 25, 112), sunX / width);
  background(skyColor);

  drawSun();
  drawClouds();
  drawGrass();
  drawFlowers();

  // Movimenta o sol
  sunX += 0.5;
  if (sunX > width + 50) {
    sunX = -50;
  }
}

function drawSun() {
  fill(255, 204, 0);
  noStroke();
  ellipse(sunX, 100, 80, 80);
}

function drawClouds() {
  fill(255);
  noStroke();
  for (let cloud of clouds) {
    ellipse(cloud.x, cloud.y, 60, 40);
    ellipse(cloud.x + 20, cloud.y + 10, 50, 30);
    ellipse(cloud.x - 20, cloud.y + 10, 50, 30);

    cloud.x += cloud.speed;
    if (cloud.x > width + 60) {
      cloud.x = -60;
      cloud.y = random(50, 150);
    }
  }
}

function drawGrass() {
  fill(34, 139, 34);
  rect(0, height / 2, width, height / 2);
}

function drawFlowers() {
  for (let i = 50; i < width; i += 100) {
    drawFlower(i, random(height / 2 + 20, height - 30));
  }
}

function drawFlower(x, y) {
  stroke(0);
  strokeWeight(2);
  line(x, y, x, y + 30); // talo

  fill(255, 105, 180);
  noStroke();
  for (let a = 0; a < TWO_PI; a += PI / 4) {
    let petalX = x + cos(a) * 10;
    let petalY = y + sin(a) * 10;
    ellipse(petalX, petalY, 10, 15);
  }

  fill(255, 215, 0); // centro da flor
  ellipse(x, y, 10, 10);
}


